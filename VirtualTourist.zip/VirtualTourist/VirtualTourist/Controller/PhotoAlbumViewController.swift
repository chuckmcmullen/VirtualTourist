//
//  PhotoAlbumViewController.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/13/21.
//

import UIKit
import MapKit
import CoreData

class PhotoAlbumViewController: UIViewController,MKMapViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource,NSFetchedResultsControllerDelegate{
     
  
    
    
    @IBOutlet weak var collectionButton: UIBarButtonItem!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet var collectionView: UICollectionView!
    let taskGroup = DispatchGroup()
    var lat:Double!
    var lon:Double!
    var pictures = [Pictures]()
    var photos = [PhotoDetail]()
    var dataController:DataController!
    var location:Location!
    //var pictureList:[PictureList] = []
    var fetchResultsController:NSFetchedResultsController<PictureList>!
    private var blockOperations: [BlockOperation] = []
    
    override func viewDidLoad() {
        //let number = Int.random(in: 0...10)
        print("lat and lon \(lat) \(lon)")
        //DispatchQueue.main.async(execute: {
        collectionView.dataSource = self
        collectionView.delegate = self
        
        self.mapView.delegate = self
        activityIndicator.isHidden = true
        setFieldsButtons()
        setPinMap()
        
        let fetchRequest:NSFetchRequest<PictureList>  = PictureList.fetchRequest()
        let sortDesc = NSSortDescriptor(key: "pictureID", ascending: false)
        let predicate = try? NSPredicate(format: "location == %@", location)
        fetchRequest.predicate = predicate
        fetchRequest.sortDescriptors = [sortDesc]
        
        fetchResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        fetchResultsController.delegate = self
        do{
            try fetchResultsController.performFetch()
            if (fetchResultsController.sections?[0].numberOfObjects == 0)
            {
                self.getPhotos(lat: lat.description, lon: lon.description,page: Int.random(in: 0...10).description)
                
            }
        }catch{
            fatalError("The fetch could not be perform \(error.localizedDescription)")
        }
        
        
       
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        fetchResultsController = nil
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //return pictureList.count
        return fetchResultsController.sections?[section].numberOfObjects ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellImage", for: indexPath) as! ImageViewController
        if let data = fetchResultsController.object(at: indexPath).pictureID as Data? {
            cell.cellImage.image = UIImage(data: data)
        }
        //if let data = self.pictureList[indexPath.item].pictureID as Data? {
        //    cell.cellImage.image = UIImage(data: data)
        //}
        
        print("image load")
        return cell
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("delete \(indexPath.row)")
        let imageDelete = fetchResultsController.object(at: indexPath)
        //let imageDelete = pictureList[indexPath.row]
        dataController.viewContext.delete(imageDelete)
        
        try? dataController.viewContext.save()
        //pictureList.remove(at: indexPath.row)
        
        //self.collectionView.reloadData()
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let pinView = MapView.sharedInstance.mapView(mapView, viewFor: annotation)
        return pinView
    }
    func setPinMap()
    {
        var annotations = [MKPointAnnotation]()
        
        let lat = CLLocationDegrees(Double(self.lat) )
        let long = CLLocationDegrees(Double(self.lon) )
        let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
        
        annotations = MapView.sharedInstance.setPinMap(lat: lat, lon: lon)
        self.mapView.addAnnotations(annotations)
        let regionRadius: CLLocationDistance = 1000
        let coordinateRegion = MKCoordinateRegion(center: coordinate,
                                                  latitudinalMeters: regionRadius * 1.0, longitudinalMeters: regionRadius * 1.0)
        self.mapView.setRegion(coordinateRegion, animated: true)
        
    }
    @objc func okTapped()
    {
        self.dismiss (animated: true, completion: nil)
        
    }
    
    @IBAction func newCollectionButton(_ sender: Any) {
        print("new collection button")
        
        let fetchRequest:NSFetchRequest<PictureList>  = PictureList.fetchRequest()
        let predicate = try? NSPredicate(format: "location == %@", location)
        fetchRequest.predicate = predicate
        if let result = try? dataController.viewContext.fetch(fetchRequest){
            for item in result {
                dataController.viewContext.delete(item)
                try? dataController.viewContext.save()
                
            }
            
            
        }
        
        //pictureList.removeAll()
        
        self.getPhotos(lat: lat.description, lon: lon.description,page: Int.random(in: 0...10).description)
        
    }
    
    func setFieldsButtons()
    {
        let okButton   = UIBarButtonItem(title:"Ok", style: UIBarButtonItem.Style.plain, target: self, action: #selector(okTapped))
                
        navigationItem.leftBarButtonItems = [okButton]
        
    }
    func getPhotos(lat:String,lon:String,page:String)
    {
        setActivityIndicator(true)
        collectionButton.isEnabled = false
        Client.getPicturelist(lat:lat,lon:lon,page:page,completion:self.handleLoginResponse(pictures: success:error:))
        
        
    }
    func handleLoginResponse(pictures:[Pictures],success:Bool,error:Error?)
    {
        if(success)
        {
            //self.pictureList.removeAll()
            self.pictures = pictures
            if(self.pictures.count > 0)
            {
                let downloadQueue = DispatchQueue(label: "download", attributes: [])
                print("start")
                
                
                for item in self.pictures {
                    self.getPhotoDetail(photoID: item.id)
                }
                //taskGroup.notify(queue: .main) { [self] in
                //    print("main done")
                //    self.setActivityIndicator(false)
                //    collectionButton.isEnabled = true
                //}
                print("done loading picture")
                
            }else
            {
                AlertView.sharedInstance.alert(view: self, title: "There are no pictures for this location", message: error?.localizedDescription ?? "")
                self.setActivityIndicator(false)
                
            }
        }
        else
        {
            print("error in ")
        }
    }
    func getPhotoDetail(photoID:String)
    {
        //taskGroup.enter()
        Client.getPhoto(photoID:photoID) { students, error in
            if(error == nil)
            {
                
                
                DispatchQueue.main.async(execute: {
                    let image = PictureList(context: self.dataController.viewContext)
                    self.photos = students
                    print(self.photos[5].source)
                   
                    let url = URL(string: self.photos[5].source)!
                    if let data = try? Data(contentsOf: url) {
                        image.pictureID = UIImage(data: data)?.jpegData(compressionQuality: 1.0)
                    }
                    image.location = self.location
                    try? self.dataController.viewContext.save()
                    //self.pictureList.append(image)
                    
                    //self.collectionView.reloadData()
                    //self.taskGroup.leave()
                })
            }
            else
            {
                print( "Can not get photos \(error?.localizedDescription ?? "")")
            }
            
            
        }
        
    }
    func setActivityIndicator(_ activity: Bool) {
        if activity {
            activityIndicator.isHidden = false
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
            activityIndicator.hidesWhenStopped = true
        }
       
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
     
     
        if type == NSFetchedResultsChangeType.insert {
     
            print("Insert Object: \(newIndexPath)")
     
            
     
            blockOperations.append(
     
                BlockOperation(block: { [weak self] in
    
                    if let this = self {
    
                        this.collectionView!.insertItems(at: [newIndexPath!])
    
                    }
    
                })
    
            )
    
        }
    
        else if type == NSFetchedResultsChangeType.update {
    
            print("Update Object: \(indexPath)")
    
            blockOperations.append(
    
                BlockOperation(block: { [weak self] in
    
                    if let this = self {
    
                        this.collectionView!.reloadItems(at: [indexPath!])
    
                    }
    
                })
    
            )
    
        }
    
        else if type == NSFetchedResultsChangeType.move {
    
            print("Move Object: \(indexPath)")
    
            
    
            blockOperations.append(
    
                BlockOperation(block: { [weak self] in
    
                    if let this = self {
    
                        this.collectionView!.moveItem(at: indexPath!, to: newIndexPath!)
    
                    }
    
                })
    
            )
    
        }
    
        else if type == NSFetchedResultsChangeType.delete {
    
            print("Delete Object: \(indexPath)")
    
            
    
            blockOperations.append(
    
                BlockOperation(block: { [weak self] in
    
                    if let this = self {
    
                        this.collectionView!.deleteItems(at: [indexPath!])
    
                    }
    
                })
    
            )
    
        }
    
    }
    
    
    public func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
    
        
    
    
        if type == NSFetchedResultsChangeType.insert {
    
            print("Insert Section: \(sectionIndex)")
    
            
    
            blockOperations.append(
    
                BlockOperation(block: { [weak self] in
    
                    if let this = self {
    
                        this.collectionView!.insertSections(NSIndexSet(index: sectionIndex) as IndexSet)
    
                    }
    
                })
    
            )
    
        }
    
        else if type == NSFetchedResultsChangeType.update {
    
            print("Update Section: \(sectionIndex)")
    
            blockOperations.append(
    
                BlockOperation(block: { [weak self] in
    
                    if let this = self {
    
                        this.collectionView!.reloadSections(NSIndexSet(index: sectionIndex) as IndexSet)
    
                    }
    
                })
    
            )
    
        }
    
        else if type == NSFetchedResultsChangeType.delete {
    
            print("Delete Section: \(sectionIndex)")
    
            
    
            blockOperations.append(
    
                BlockOperation(block: { [weak self] in
    
                    if let this = self {
    
                        this.collectionView!.deleteSections(NSIndexSet(index: sectionIndex) as IndexSet)
    
                    }
    
                })
    
            )
    
        }
    
    }
    
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    
        collectionView!.performBatchUpdates({ () -> Void in
    
                for operation: BlockOperation in self.blockOperations {
    
                    operation.start()
    
                }
    
            }, completion: { (finished) -> Void in
    
                self.blockOperations.removeAll(keepingCapacity: false)
    
        })
    
    }
}
