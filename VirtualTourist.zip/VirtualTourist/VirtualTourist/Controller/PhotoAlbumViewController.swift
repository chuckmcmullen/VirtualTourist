//
//  PhotoAlbumViewController.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/13/21.
//

import UIKit
import MapKit
import CoreData

class PhotoAlbumViewController: UIViewController,MKMapViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource{
       
    @IBOutlet weak var collectionButton: UIBarButtonItem!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet var collectionView: UICollectionView!
    let taskGroup = DispatchGroup()
    var lat:Double!
    var lon:Double!
    var pictures = [Pictures]()
    //var photos = [PhotoDetail]()
    var dataController:DataController!
    var location:Location!
    //var pictureList:[PictureList] = []
    var fetchResultsController:NSFetchedResultsController<PictureList>!
    private var blockOp = BlockOperation()
    var count:Int = 0
    var tempcnt:Int=0
    override func viewDidLoad() {
        collectionView.dataSource = self
        collectionView.delegate = self
        self.mapView.delegate = self
        activityIndicator.isHidden = true
        setFieldsButtons()
        setPinMap()
        setFetchRequest()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        fetchResultsController = nil
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("NO\(fetchResultsController.sections?[section].numberOfObjects ?? 0)")
        return fetchResultsController.sections?[section].numberOfObjects ?? 0
        //print("COUNT\(count)")
        //return pictures.count
        //return count
    }
    private func numberOfSectionsInCollectionView(collectionView: UICollectionView!) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let data = fetchResultsController.object(at: indexPath)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellImage", for: indexPath) as! ImageViewController
        
        if let imagePhoto = data.pictureID {
            cell.cellImage.image = UIImage(data: imagePhoto)
        }
        else{
            self.downloadImage(imagePath: data.urlString!){ myData, error in
                if(error == nil){
                    print("dowload image\(self.tempcnt)")
                    print("dowload image\(data.urlString)")
                    print(indexPath)
                    self.tempcnt = self.tempcnt + 1
                    data.setValue(myData, forKey: "pictureID")
                    try? self.dataController.viewContext.save()
                    DispatchQueue.main.async(execute: { () -> Void in
                        cell.cellImage.image = UIImage(data: myData!)
                    })
                }
            }
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let imageDelete = fetchResultsController.object(at: indexPath)
        dataController.viewContext.delete(imageDelete)
        try? dataController.viewContext.save()
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let pinView = MapView.sharedInstance.mapView(mapView, viewFor: annotation)
        return pinView
    }
    func setPinMap()
    {
        var annotations = [MKPointAnnotation]()
        
        let lat = CLLocationDegrees(Double(self.lat) )
        let long = CLLocationDegrees(Double(self.lon) )
        let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
        
        annotations = MapView.sharedInstance.setPinMap(lat: lat, lon: lon)
        self.mapView.addAnnotations(annotations)
        let regionRadius: CLLocationDistance = 1000
        let coordinateRegion = MKCoordinateRegion(center: coordinate,
                                                  latitudinalMeters: regionRadius * 1.0, longitudinalMeters: regionRadius * 1.0)
        self.mapView.setRegion(coordinateRegion, animated: true)
        
    }
    @objc func okTapped()
    {
        self.dismiss (animated: true, completion: nil)
        
    }
    
    @IBAction func newCollectionButton(_ sender: Any) {
        deleteAllPhotos()
        self.getPhotos(lat: lat.description, lon: lon.description,page: Int.random(in: 0...10).description)
        
    }
    func deleteAllPhotos()
    {
        pictures.removeAll()
        if let result = self.fetchResultsController.fetchedObjects {
            for item in result {
                dataController.viewContext.delete(item)
                try? dataController.viewContext.save()
            }
        }
    }
    func setFieldsButtons()
    {
        let okButton = UIBarButtonItem(title:"Ok", style: UIBarButtonItem.Style.plain, target: self, action: #selector(okTapped))
        navigationItem.leftBarButtonItems = [okButton]
    }
    func getPhotos(lat:String,lon:String,page:String)
    {
        setActivityIndicator(true)
        collectionButton.isEnabled = false
        Client.getPicturelist(lat:lat,lon:lon,page:page,completion:self.handleLoginResponse(pictures: success:error:))
     }
    func handleLoginResponse(pictures:[Pictures],success:Bool,error:Error?)
    {
        if(success)
        {
            self.pictures = pictures
            if(self.pictures.count > 0)
            {
                for item in self.pictures{
                    Client.getPhoto(photoID:item.id) { photos, error in
                        if(error == nil){
                            let image2 = PictureList(context: self.dataController.viewContext)
                            image2.urlString = photos[0].source
                            //image2.pictureID = myData
                            image2.location = self.location
                            try? self.dataController.viewContext.save()
                            //self.collectionView.reloadData()
                            print("here in getPhoto")
                        }
                    }
                }
                count = self.pictures.count
                
                self.setActivityIndicator(false)
                collectionButton.isEnabled = true
            }else
            {
                AlertView.sharedInstance.alert(view: self, title: "There are no pictures for this location", message: error?.localizedDescription ?? "")
                self.setActivityIndicator(false)
            }
        }
    }
    func setActivityIndicator(_ activity: Bool) {
        if activity {
            activityIndicator.isHidden = false
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
            activityIndicator.hidesWhenStopped = true
        }

    }
    func setFetchRequest()
    {
        let fetchRequest:NSFetchRequest<PictureList>  = PictureList.fetchRequest()
        let sortDesc = NSSortDescriptor(key: "urlString", ascending: false)
        let predicate = try? NSPredicate(format: "location == %@", location)
        fetchRequest.predicate = predicate
        fetchRequest.sortDescriptors = [sortDesc]
        
        fetchResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        fetchResultsController.delegate = self
        do{
            try fetchResultsController.performFetch()
            if (fetchResultsController.sections?[0].numberOfObjects == 0)
            {
                self.getPhotos(lat: lat.description, lon: lon.description,page: Int.random(in: 0...10).description)
                
            }
            else
            {
                count = (fetchResultsController.sections?[0].numberOfObjects)!
                
            }
        }catch{
            fatalError("The fetch could not be perform \(error.localizedDescription)")
        }
        
    }
    func downloadImage( imagePath:String, completionHandler: @escaping (_ imageData: Data?, _ errorString: String?) -> Void){
        let session = URLSession.shared
        let imgURL = NSURL(string: imagePath)
        let request: NSURLRequest = NSURLRequest(url: imgURL! as URL)
        let task = session.dataTask(with: request as URLRequest) {data, response, downloadError in
            if downloadError != nil {
                completionHandler(nil, "Could not download image \(imagePath)")
            } else {
                
                completionHandler(data, nil)
            }
        }
            task.resume()
        }
    }
extension PhotoAlbumViewController: NSFetchedResultsControllerDelegate{
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        blockOp = BlockOperation()
        }

        func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
            let sectionIndexSet = IndexSet(integer: sectionIndex)

            switch type {
            case .insert:
                blockOp.addExecutionBlock {
                    self.collectionView?.insertSections(sectionIndexSet)
                    
                }
            case .delete:
                blockOp.addExecutionBlock {
                    self.collectionView?.deleteSections(sectionIndexSet)
                }
            case .update:
                blockOp.addExecutionBlock {
                    self.collectionView?.reloadSections(sectionIndexSet)
                }
            case .move:
                assertionFailure()
                break
            }
        }

        func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
            switch type {
            case .insert:
                guard let newIndexPath = newIndexPath else { break }

                blockOp.addExecutionBlock {
                   self.collectionView?.insertItems(at: [newIndexPath])
                    
                }
            case .delete:
                guard let indexPath = indexPath else { break }

                blockOp.addExecutionBlock {
                    self.collectionView?.deleteItems(at: [indexPath])
                }
            case .update:
                guard let indexPath = indexPath else { break }

                blockOp.addExecutionBlock {
                    self.collectionView?.reloadItems(at: [indexPath])
                }
            case .move:
                guard let indexPath = indexPath, let newIndexPath = newIndexPath else { return }

                blockOp.addExecutionBlock {
                    self.collectionView?.moveItem(at: indexPath, to: newIndexPath)
                }
            }
        }

        func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
            
            collectionView?.performBatchUpdates({
                self.blockOp.start()
                }, completion: nil)
        }
}
