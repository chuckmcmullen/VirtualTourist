//
//  MapViewController.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/9/21.
//

import UIKit
import MapKit
import CoreData

class MapViewController: UIViewController, UIGestureRecognizerDelegate, MKMapViewDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var imageView: UIImageView!
    var lat:Double!
    var lon:Double!
    var pictures = [Pictures]()
    var photos = [PhotoDetail]()
    var locations:[Location] = []
    var dataController:DataController!
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        self.mapView.delegate = self
        
        let fetchRequest:NSFetchRequest<Location> = Location.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "latitude", ascending: true)
        
        fetchRequest.sortDescriptors = [sortDescriptor]
        if let result = try? dataController.viewContext.fetch(fetchRequest){
            print("Core Data cnt:\(result.count)")
            locations = result
            for item in result {
                //var location = Locations(latitude: item.latitude, longitude: item.longitude)
                print("LAT:\(item.latitude)")
                print("LON:\(item.longitude)")
                //locations.append(location)
                setPinMap(lat: item.latitude, lon: item.longitude)
            }
        }
        var tempLat = UserDefaults.standard.double(forKey: "latKey")
        var tempLon = UserDefaults.standard.double(forKey: "lonKey")
        var tempDeltaLat = UserDefaults.standard.double(forKey: "latDeltaKey")
        var tempDeltaLon = UserDefaults.standard.double(forKey: "lonDeltaKey")
        //print("Lat \(tempLat)")
        //print("Lat \(tempLon)")
        if(tempLat != 0.0)
        {
            let coordinate = CLLocationCoordinate2D(latitude: tempLat, longitude: tempLon)
            self.mapView.setCenter(coordinate, animated: true)
            
            let uu = MKCoordinateSpan(latitudeDelta: tempDeltaLat, longitudeDelta: tempDeltaLon)
            let yy = MKCoordinateRegion(center: coordinate, span: uu)
            self.mapView.setRegion(yy, animated: true)
        }
        let longTapGesture = UILongPressGestureRecognizer(target: self, action: #selector(longTap))
        mapView.addGestureRecognizer(longTapGesture)
        
       
    }
    override func viewDidAppear(_ animated: Bool) {
       
        
    }
    @objc func longTap(sender: UIGestureRecognizer){
        print("long tap")
        if sender.state == .began {
            let locationInView = sender.location(in: mapView)
            let locationOnMap = mapView.convert(locationInView, toCoordinateFrom: mapView)
            
            print("LAT:\(locationOnMap.latitude)")
            print("LON:\(locationOnMap.longitude)")
            addAnnotation(location: locationOnMap)
            saveLocation(lat: locationOnMap.latitude, lon: locationOnMap.longitude)
            
        }
    }
    @objc func shortTap(sender: UIGestureRecognizer){
        print("short tap")
        
    }
    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        let zoomWidth = mapView.visibleMapRect.size.width
        let zoomFactor = Int(log2(zoomWidth)) - 9
        print("...REGION DID CHANGE: ZOOM FACTOR \(zoomFactor)")
        print(mapView.region.span.latitudeDelta)
        print(mapView.region.span.longitudeDelta)
        UserDefaults.standard.set(mapView.centerCoordinate.latitude, forKey: "latKey")
        UserDefaults.standard.set(mapView.centerCoordinate.longitude, forKey: "lonKey")
        UserDefaults.standard.set(mapView.region.span.latitudeDelta, forKey: "latDeltaKey")
        UserDefaults.standard.set(mapView.region.span.longitudeDelta, forKey: "lonDeltaKey")
    }
    func setPinMap(lat:Double,lon:Double)
    {
        var annotations = [MKPointAnnotation]()
        
        annotations = MapView.sharedInstance.setPinMap(lat: lat, lon: lon)
        self.mapView.addAnnotations(annotations)
        
        
    }
    func addAnnotation(location: CLLocationCoordinate2D){
            let annotation = MKPointAnnotation()
            annotation.coordinate = location
            
            lat = location.latitude
            lon = location.longitude
            self.mapView.addAnnotation(annotation)
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        var pinView = MapView.sharedInstance.mapView(mapView, viewFor: annotation)
        return pinView
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        var coordinateRegion = MKCoordinateRegion()
        
        
        coordinateRegion = self.mapView.region
        
        
        
        print("saved data \(coordinateRegion.span)")
        print("saved data \(view.annotation?.coordinate.latitude)")
        self.lat = view.annotation?.coordinate.latitude
        self.lon = view.annotation?.coordinate.longitude
        self.performSegue(withIdentifier: "photoAlbumSegue", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "photoAlbumSegue"{
            var tempLocation:Location
            let nav = segue.destination as! UINavigationController
            let vc = nav.topViewController as! PhotoAlbumViewController
            vc.lat = self.lat
            vc.lon = self.lon
            print("HERE LAT:\(self.lat)")
            print("HERE LON:\(self.lon)")
            let fetchRequest:NSFetchRequest<Location>  = Location.fetchRequest()
            let predicate = NSPredicate(format: "latitude > %f AND latitude < %f and longitude > %f and longitude < %f",self.lat - 0.00001,self.lat + 0.00001,self.lon - 0.00001,self.lon + 0.00001)
            fetchRequest.predicate = predicate
            if let result = try? dataController.viewContext.fetch(fetchRequest){
                if(result.count > 0){
                    print("here in get location:\(result.count)")
                    vc.location = result[0]
                    
                }
                else{
                    print("here in get location:\(result.count)")
                    
                    
                    
                }
                
                
            }
            vc.dataController = dataController
        }
        
    }
    
    func saveLocation(lat:Double,lon:Double)
    {
        let location = Location(context: dataController.viewContext)
        location.latitude = lat
        location.longitude = lon
        try? dataController.viewContext.save()
    }
}
