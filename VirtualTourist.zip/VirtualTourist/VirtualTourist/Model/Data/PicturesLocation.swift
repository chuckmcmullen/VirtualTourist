//
//  PicturesLocation.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/9/21.
//

import Foundation
class StudentModel {
    
    static var pictureLocationList = [Pictures]()
    
    
}
