//
//  Locations.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/23/21.
//

import Foundation
struct Locations {
    var latitude:Double
    var longitude:Double
    
}
