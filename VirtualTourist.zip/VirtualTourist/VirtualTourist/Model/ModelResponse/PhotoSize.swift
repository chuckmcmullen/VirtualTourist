//
//  PhotoSize.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/10/21.
//

import Foundation
struct PhotoSize: Codable, Equatable {
    let canblog:Int
    let canprint:Int
    let candownload:Int
    let size: [PhotoDetail]
           
    enum CodingKeys: String, CodingKey {
        case canblog
        case canprint
        case candownload
        case size
        
    }
}
