//
//  PictureErrorResponse.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/9/21.
//

import Foundation
struct PictureErrorResponse: Codable, Equatable {
    
    let stat: String
    let code: Int
    let message:String
    enum CodingKeys: String, CodingKey {
        case stat
        case code
        case message
    }
}
extension PictureErrorResponse: LocalizedError {
    var errorDescription: String? {
        return message
    }
}
