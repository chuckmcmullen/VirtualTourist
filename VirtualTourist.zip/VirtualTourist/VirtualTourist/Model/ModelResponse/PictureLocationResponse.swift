//
//  PictureLocationResponse.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/9/21.
//

import Foundation
struct PictureLocationResponse: Codable, Equatable {
    
    let page: Int
    let pages: Int
    let perpage: Int
    let total: String
    let photo: [Pictures]
   
    enum CodingKeys: String, CodingKey {
        case page
        case pages
        case perpage
        case total
        case photo
        
    }
}
