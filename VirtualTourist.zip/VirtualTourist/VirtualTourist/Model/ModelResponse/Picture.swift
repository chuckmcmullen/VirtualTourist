//
//  Picture.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/9/21.
//

import Foundation
struct Picture: Codable, Equatable {
    
    let photos: PictureLocationResponse
    let stat: String
       
    enum CodingKeys: String, CodingKey {
        case photos
        case stat
    }
}
