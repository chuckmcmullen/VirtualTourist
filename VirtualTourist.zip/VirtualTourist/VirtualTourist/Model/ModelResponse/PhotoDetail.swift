//
//  PhotoDetail.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/10/21.
//

import Foundation
struct PhotoDetail: Codable, Equatable {
    let label: String
    let width: Int
    let height: Int
    let source: String
    let url: String
    let media: String
       
    enum CodingKeys: String, CodingKey {
        case label
        case width
        case height
        case source
        case url
        case media
    }
}
