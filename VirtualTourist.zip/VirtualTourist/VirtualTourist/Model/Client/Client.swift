//
//  Client.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/9/21.
//
import Foundation
class Client{
    static let apiKey = "a0cb2579bf9fb6a29ff684279d1a94a2"
    struct Auth {
        static var accountId = 0
        static var requestToken = ""
        static var sessionId = ""
    }
    
    enum Endpoints {
        static let base = "https://www.flickr.com/services/rest"
        case getPhotoList(String,String,String)
        case getPhoto(String)
        var stringValue: String {
            switch self {
            case .getPhotoList(let lat,let lon,let page): return Endpoints.base + "/?method=flickr.photos.search&api_key=a0cb2579bf9fb6a29ff684279d1a94a2&lat=\(lat)&lon=\(lon)&per_page=20&format=json&nojsoncallback=1&page=\(page)"
            case .getPhoto(let photoID): return Endpoints.base + "/?method=flickr.photos.getSizes&api_key=a0cb2579bf9fb6a29ff684279d1a94a2&photo_id=\(photoID)&format=json&nojsoncallback=1"
            }
            
        }
        var url: URL {
            return URL(string: stringValue)!
        }
        
    }
    class func getPicturelist(lat:String,lon:String,page:String,completion: @escaping ([Pictures],Bool, Error?) -> Void) {
        taskForGETRequest(url: Endpoints.getPhotoList(lat,lon,page).url, responseType:
                           Picture.self) { (response, error) in
            if let response = response {
                completion(response.photos.photo,true, nil)
            } else {
                completion([],false, error)
            }
        }
    }
    class func getPhoto(photoID:String,completion: @escaping ([PhotoDetail], Error?) -> Void) {
            taskForGETRequest(url: Endpoints.getPhoto(photoID).url, responseType:
                               PhotoSizes.self) { (response, error) in
                if let response = response {
                    completion(response.sizes.size, nil)
                } else {
                    completion([], error)
                }
            }
        }
    class func taskForGETRequest<ResponseType: Decodable>(url: URL, responseType: ResponseType.Type, completion: @escaping (ResponseType?, Error?) -> Void)
    {
             
        let task = URLSession.shared.dataTask(with: url) { data, responseType, error in
            if error != nil {
                DispatchQueue.main.async {
                    completion(nil,error)
                }
            return
            }
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(ResponseType.self, from: data)
                DispatchQueue.main.async {
                    completion(responseObject, nil)
                }
            } catch {
                do {
                    let errorResponse = try decoder.decode(PictureErrorResponse.self, from: data) as Error
                    DispatchQueue.main.async {
                        completion(nil, errorResponse)
                        
                    }
                } catch {
                    DispatchQueue.main.async {
                        completion(nil, error)
                    }
                }
            }
        }
        task.resume()
    }
    
}
