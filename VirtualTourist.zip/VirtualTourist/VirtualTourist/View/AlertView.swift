//
//  AlertView.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/15/21.
//

import UIKit
class AlertView: NSObject {//This is shared class
static let sharedInstance = AlertView()

    func alert(view: UIViewController, title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let defaultAction = UIAlertAction(title: "OK", style: .default, handler: { action in
        })
        alert.addAction(defaultAction)
        DispatchQueue.main.async(execute: {
            view.present(alert, animated: true)
        })
    }

    private override init() {
    }
}
