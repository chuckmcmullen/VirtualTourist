//
//  ImageViewController.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/13/21.
//

import UIKit
class ImageViewController:UICollectionViewCell{
    
    @IBOutlet weak var cellImage: UIImageView!
}
