//
//  MapView.swift
//  VirtualTourist
//
//  Created by Chuck McMullen on 4/25/21.
//

import UIKit
import MapKit
class MapView: NSObject {//This is shared class
static let sharedInstance = MapView()

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView

        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        
        return pinView
    }
    func setPinMap(lat:Double,lon:Double) -> [MKPointAnnotation]
    {
        var annotations = [MKPointAnnotation]()
        
        let lat = CLLocationDegrees(Double(lat) )
        let long = CLLocationDegrees(Double(lon) )
        let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
        let annotation = MKPointAnnotation()
        
        annotation.coordinate = coordinate
        annotations.append(annotation)
        
        return annotations
        
    }
    private override init() {
    }
}
